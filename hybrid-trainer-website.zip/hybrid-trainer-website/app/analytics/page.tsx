"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, BarChart2, Heart, LineChart, TrendingUp, Calendar, Zap } from 'lucide-react'
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'

const performanceData = [
  { date: '2023-01-01', pace: 5.8, distance: 10, time: 40 },
  { date: '2023-02-01', pace: 5.6, distance: 12, time: 45 },
  { date: '2023-03-01', pace: 5.4, distance: 15, time: 50 },
  { date: '2023-04-01', pace: 5.2, distance: 18, time: 55 },
  { date: '2023-05-01', pace: 5.0, distance: 20, time: 60 },
  { date: '2023-06-01', pace: 4.9, distance: 22, time: 65 },
]

export default function AnalyticsPage() {
  const [timePeriod, setTimePeriod] = useState("30d")

  return (
    <div className="container space-y-8 px-4 py-8 md:px-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-muted-foreground">
            Detailed analysis of your training performance and progress.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={timePeriod} onValueChange={setTimePeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button>Export Data</Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[
              { title: "Average Pace", value: "5:30/km", change: "+2.4% vs last period", icon: Activity },
              { title: "Distance Covered", value: "284.5 km", change: "+8.1% vs last period", icon: LineChart },
              { title: "Training Hours", value: "42.5", change: "+12.3% vs last period", icon: BarChart2 },
              { title: "Average Heart Rate", value: "142 BPM", change: "-3.2% vs last period", icon: Heart },
            ].map((stat, index) => (
              <Card key={index}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <stat.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <TrendingUp className="h-3 w3" />
                    <span>{stat.change}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Your key metrics over time</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Line yAxisId="left" type="monotone" dataKey="pace" stroke="#8884d8" name="Pace (min/km)" />
                    <Line yAxisId="right" type="monotone" dataKey="distance" stroke="#82ca9d" name="Distance (km)" />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Training Distribution</CardTitle>
                <CardDescription>Breakdown by activity type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { activity: "Running", percentage: 45, icon: Activity },
                    { activity: "Cycling", percentage: 30, icon: Zap },
                    { activity: "Swimming", percentage: 15, icon: LineChart },
                    { activity: "Strength Training", percentage: 10, icon: BarChart2 },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center">
                      <item.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">{item.activity}</span>
                          <span className="text-sm font-medium">{item.percentage}%</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full">
                          <div
                            className="h-2 bg-primary rounded-full"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Performance Metrics</CardTitle>
              <CardDescription>In-depth analysis of your training data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {[
                    { title: "VO2 Max", value: "48.5 ml/kg/min", change: "+1.2 from last test", icon: Heart },
                    { title: "Lactate Threshold", value: "172 BPM", change: "+3 BPM from last test", icon: Activity },
                    { title: "Running Economy", value: "210 ml/kg/km", change: "-5 ml/kg/km improvement", icon: Zap },
                    { title: "FTP (Cycling)", value: "280 watts", change: "+15 watts from last test", icon: BarChart2 },
                    { title: "Swim CSS", value: "1:35 /100m", change: "-3 seconds from last test", icon: LineChart },
                    { title: "Resting Heart Rate", value: "52 BPM", change: "-2 BPM from last month", icon: Heart },
                  ].map((metric, index) => (
                    <Card key={index}>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
                        <metric.icon className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{metric.value}</div>
                        <p className="text-xs text-muted-foreground">{metric.change}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Progress Tracking</CardTitle>
              <CardDescription>Monitor your improvements over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="grid gap-4 md:grid-cols-2">
                  {[
                    { title: "5K Personal Best", value: "22:30", change: "-45 seconds this year", icon: Calendar },
                    { title: "Half Marathon PB", value: "1:45:22", change: "-3:18 this year", icon: Calendar },
                    { title: "Max Squat", value: "120 kg", change: "+15 kg this year", icon: BarChart2 },
                    { title: "100m Swim PB", value: "1:12", change: "-4 seconds this year", icon: LineChart },
                  ].map((progress, index) => (
                    <Card key={index}>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">{progress.title}</CardTitle>
                        <progress.icon className="h-4 w-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{progress.value}</div>
                        <p className="text-xs text-muted-foreground">{progress.change}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

