"use client"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Activity, BarChart2, Heart, MonitorIcon as Running, Smartphone, Trophy, TrendingUp, Calendar } from 'lucide-react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts'

const performanceData = [
  { date: 'Mon', workouts: 2, duration: 90 },
  { date: 'Tue', workouts: 1, duration: 60 },
  { date: 'Wed', workouts: 3, duration: 120 },
  { date: 'Thu', workouts: 2, duration: 75 },
  { date: 'Fri', workouts: 1, duration: 45 },
  { date: 'Sat', workouts: 4, duration: 180 },
  { date: 'Sun', workouts: 2, duration: 100 },
]

const activityDistribution = [
  { name: 'Running', value: 40 },
  { name: 'Cycling', value: 30 },
  { name: 'Swimming', value: 15 },
  { name: 'Strength', value: 15 },
]

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']

export default function DashboardPage() {
  return (
    <div className="container space-y-8 px-4 py-8 md:px-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back! Here&apos;s an overview of your training progress.
          </p>
        </div>
        <Button>Start New Workout</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        {[
          { title: "Total Workouts", value: "248", change: "+12% from last month", icon: Activity },
          { title: "Active Minutes", value: "1,420", change: "+8% from last month", icon: Running },
          { title: "Average Heart Rate", value: "142 BPM", change: "-3% from last month", icon: Heart },
          { title: "Achievement Points", value: "1,280", change: "+18% from last month", icon: Trophy },
          { title: "iOS App Status", value: "Coming Soon", change: "Join the beta waitlist", icon: Smartphone },
        ].map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Performance Overview</CardTitle>
            <CardDescription>Your training metrics for the past 7 days</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Line yAxisId="left" type="monotone" dataKey="workouts" stroke="#8884d8" name="Workouts" />
                <Line yAxisId="right" type="monotone" dataKey="duration" stroke="#82ca9d" name="Duration (min)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Activity Distribution</CardTitle>
            <CardDescription>Breakdown of your training activities</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={activityDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {activityDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
          <CardDescription>Your latest training sessions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { activity: "High Intensity Training", duration: "45 minutes", calories: 320, icon: TrendingUp },
              { activity: "Long Distance Run", duration: "90 minutes", calories: 750, icon: Running },
              { activity: "Strength Training", duration: "60 minutes", calories: 280, icon: BarChart2 },
              { activity: "Recovery Swim", duration: "30 minutes", calories: 200, icon: Activity },
            ].map((activity, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="relative aspect-square w-12 overflow-hidden rounded-lg bg-muted">
                  <activity.icon className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-muted-foreground" />
                </div>
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium leading-none">{activity.activity}</p>
                  <p className="text-sm text-muted-foreground">{activity.duration} • {activity.calories} calories</p>
                </div>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>iOS App Integration</CardTitle>
          <CardDescription>Get ready for our upcoming mobile experience</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Our iOS app is currently in development and will soon bring the power of HybridTrainer to your mobile device. Stay tuned for these exciting features:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Real-time workout tracking</li>
            <li>Instant access to your performance analytics</li>
            <li>Personalized training recommendations on-the-go</li>
            <li>Seamless data synchronization with your web account</li>
          </ul>
          <Button className="mt-6">Join iOS Beta Waitlist</Button>
        </CardContent>
      </Card>
    </div>
  )
}

